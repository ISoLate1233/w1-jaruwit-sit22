void main (){
  double c1 = 25.0;
  double c2 = 0.0;
  double c3 = 60.0;

  double fahrenheit1 = (c1 * 9 / 5) + 32;
  double fahrenheit2 = (c2 * 9 / 5) + 32;
  double fahrenheit3 = (c3 * 9 / 5) + 32;

  print('$c1°C = $fahrenheit1°F');
  print('$c2°C = $fahrenheit2°F');
  print('$c3°C = $fahrenheit3°F');
}