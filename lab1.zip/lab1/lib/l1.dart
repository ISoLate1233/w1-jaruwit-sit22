void main() {
  String name = "Name : Jaruwit";
  String age = "Age : 19";
  String height = "Height : 180";
  String grade = "Grade : 2.00";
  String isStudent = "Status are Student is True";
  String province = "Provinve : Chonburi";
  print (name);
  print(age);
  print(height);
  print(grade);
  print(isStudent);
  print(province);
}